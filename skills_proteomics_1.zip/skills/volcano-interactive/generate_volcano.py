"""
generate_volcano.py
====================
CPTAC HCC DE + quant CSV를 읽어 인터랙티브 Volcano+Heatmap+GO HTML 생성

사용법:
    python generate_volcano.py

출력:
    volcano_interactive.html  (브라우저에서 바로 열기)

데이터 출처:
    https://github.com/heeyounh/proteomics-lecture/tree/main/data
"""

import pandas as pd
import numpy as np
import json

# ── 1. 데이터 로드 ────────────────────────────────────────────
BASE = "https://raw.githubusercontent.com/heeyounh/proteomics-lecture/main/data/"

print("데이터 로드 중...")
de    = pd.read_csv(BASE + "cptac_hcc_DE.csv",    index_col=0)
quant = pd.read_csv(BASE + "cptac_hcc_quant.csv", index_col=0)
print(f"  DE: {de.shape}, quant: {quant.shape}")

# ── 2. Volcano 데이터 JSON 변환 ───────────────────────────────
de["neglog10p"] = -np.log10(de["p_value"].clip(lower=1e-10))

ALL = [
    {
        "x":    round(float(r["log2FC"]),   4),
        "y":    round(float(r["neglog10p"]), 4),
        "gene": str(idx),
        "p":    float(r["p_value"]),
        "fdr":  round(float(r["FDR"]), 4) if pd.notna(r["FDR"]) else None,
        "ps":   f"{r['p_value']:.2e}"
    }
    for idx, r in de.iterrows()
]

# ── 3. Quant 데이터 JSON 변환 (p<0.1 후보만) ─────────────────
cands = set(de[de["p_value"] < 0.1].index)
sample_order  = ["C1_s1","C1_s2","C1_s3","C1_s4","C1_s5",
                 "C2_s1","C2_s2","C2_s3","C2_s4","C2_s5"]
QUANT = {
    g: quant.loc[g, sample_order].clip(-5, 5).round(3).tolist()
    for g in cands if g in quant.index
}
SAMPLES = ["C1_s1","C1_s2","C1_s3","C1_s4","C1_s5",
           "C2_s1","C2_s2","C2_s3","C2_s4","C2_s5"]

DATA    = {"all": ALL, "quant": QUANT, "samples": SAMPLES}
DATA_JS = json.dumps(DATA, ensure_ascii=False)
print(f"  DATA JSON: {len(DATA_JS)//1024}KB")

# ── 4. CSS / JS / HTML ────────────────────────────────────────
CSS = """
*{box-sizing:border-box;margin:0;padding:0;}
html,body{width:100%;height:100%;background:#0f172a;overflow:hidden;font-family:'Noto Sans KR',sans-serif;}
.deck{width:100vw;height:100vh;display:flex;align-items:center;justify-content:center;}
.slide-wrapper{width:1280px;height:720px;transform-origin:center;position:relative;
  overflow:hidden;flex-shrink:0;background:#fff;display:flex;flex-direction:column;}

.slide-header{background:#1e3a5f;color:#fff;padding:12px 32px;
  display:flex;align-items:center;justify-content:space-between;flex-shrink:0;}
.header-left{display:flex;align-items:center;gap:12px;}
.accent-bar{width:5px;height:24px;background:#4fd1c5;border-radius:3px;}
.slide-header h2{font-size:20px;font-weight:500;}
.hdr-badge{font-size:12px;font-family:'JetBrains Mono',monospace;color:#4fd1c5;}

.ctrl-panel{display:flex;align-items:center;gap:14px;padding:7px 28px;
  background:#f9f8f5;border-bottom:1px solid #e8e7e4;flex-shrink:0;}
.ctrl-group{display:flex;align-items:center;gap:8px;}
.ctrl-label{font-size:12px;font-weight:600;color:#475569;}
.ctrl-val{font-family:'JetBrains Mono',monospace;background:#e2e8f0;
  border-radius:4px;padding:2px 7px;font-size:12px;color:#1e293b;min-width:72px;text-align:center;}
input[type=range]{accent-color:#1e3a5f;width:110px;cursor:pointer;}

.btn{padding:5px 13px;border-radius:6px;border:1px solid #e2e8f0;background:white;
  font-size:12px;cursor:pointer;color:#334155;font-family:'Noto Sans KR',sans-serif;}
.btn:hover{background:#f1f5f9;}
.btn:disabled{opacity:0.4;cursor:not-allowed;}
.btn.save{background:#1e3a5f;color:white;border:none;}
.btn.heatmap-btn{background:#7c3aed;color:white;border:none;font-weight:600;}
.btn.go-btn{background:#059669;color:white;border:none;font-weight:600;}
.btn.back-btn{background:#475569;color:white;border:none;}
.btn.tab{background:white;border:1px solid #e2e8f0;color:#334155;}
.btn.tab.active{background:#059669;color:white;border-color:#059669;}
.sig-count{font-size:12px;font-family:'JetBrains Mono',monospace;color:#64748b;}

.view{flex:1;min-height:0;display:flex;flex-direction:column;overflow:hidden;}
.view.hidden{display:none;}

#volcano-chart-area{flex:1;min-height:0;position:relative;}
#vc{width:100%!important;height:100%!important;}
.volcano-footer{display:flex;align-items:center;justify-content:space-between;
  padding:6px 28px;flex-shrink:0;border-top:1px solid #f1f5f9;}
.stats{display:flex;gap:20px;}
.stat .n{font-size:18px;font-weight:700;}
.stat .l{font-size:11px;color:#64748b;}
.stat.up .n{color:#E74C3C;}
.stat.dn .n{color:#3498DB;}

.hm-info{padding:6px 28px;background:#f0fdf4;border-bottom:1px solid #bbf7d0;
  flex-shrink:0;display:flex;align-items:center;gap:14px;}
.hm-badge{font-size:12px;font-family:'JetBrains Mono',monospace;color:#065f46;
  background:#bbf7d0;border-radius:4px;padding:2px 8px;}
.hm-note{font-size:12px;color:#475569;}
.hm-body{flex:1;min-height:0;}
#hm-canvas{width:100%;height:100%;display:block;}

.go-info{padding:6px 28px;background:#f0fdf9;border-bottom:1px solid #99f6e4;
  flex-shrink:0;display:flex;align-items:center;gap:12px;}
.go-badge{font-size:12px;font-family:'JetBrains Mono',monospace;color:#065f46;
  background:#99f6e4;border-radius:4px;padding:2px 8px;}
.go-body{flex:1;min-height:0;position:relative;}
#go-canvas{width:100%;height:100%;display:block;}

#go-loading{position:absolute;inset:0;display:flex;flex-direction:column;
  align-items:center;justify-content:center;background:white;gap:16px;z-index:10;}
#go-loading.hidden{display:none;}
.spinner{width:36px;height:36px;border:4px solid #e2e8f0;
  border-top-color:#059669;border-radius:50%;animation:spin 0.8s linear infinite;}
@keyframes spin{to{transform:rotate(360deg);}}
#go-loading p{font-size:14px;color:#64748b;}

.vc-tip{position:fixed;pointer-events:none;background:#0f172a;color:#e2e8f0;
  border-radius:8px;padding:10px 14px;font-family:'JetBrains Mono',monospace;
  font-size:12px;line-height:1.8;box-shadow:0 4px 12px rgba(0,0,0,0.3);
  z-index:999;display:none;min-width:180px;}
.vc-tip-gene{font-size:14px;font-weight:700;color:#4fd1c5;margin-bottom:4px;}

#go-popup{position:fixed;display:none;background:white;border:1px solid #e2e8f0;
  border-radius:10px;box-shadow:0 8px 24px rgba(0,0,0,0.15);padding:16px 20px;
  max-width:380px;z-index:1000;font-size:12px;}
#go-popup h4{font-size:13px;color:#1e3a5f;margin-bottom:8px;line-height:1.4;}
#go-popup .genes{color:#475569;line-height:1.7;word-break:break-all;}
#go-popup .close-btn{position:absolute;top:8px;right:12px;cursor:pointer;color:#94a3b8;font-size:16px;}
.progress-bar{position:absolute;bottom:0;left:0;height:4px;background:#4fd1c5;width:100%;}
"""

JS = r"""
const DATA  = JSON.parse(document.getElementById('app-data').textContent);
const ALL   = DATA.all;
const QUANT = DATA.quant;
const SAMP  = DATA.samples;

let curLfc = 1.0, curPval = 0.01;
let vchart  = null;
let _enrichrId  = null;
let _goResults  = {};
let _curGeneSet = 'GO_Biological_Process_2023';
let _sigGenes   = [];

function scale() {
  const s = Math.min(window.innerWidth/1280, window.innerHeight/720);
  document.getElementById('wrapper').style.transform = `scale(${s})`;
}
window.addEventListener('resize', scale);

const linePlugin = {
  id: 'threshLines',
  afterDraw(chart) {
    const {ctx, scales:{x,y}} = chart;
    const pL = -Math.log10(curPval);
    ctx.save(); ctx.setLineDash([5,4]);
    ctx.strokeStyle='rgba(100,116,139,0.6)'; ctx.lineWidth=1;
    const py = y.getPixelForValue(pL);
    if (py >= y.top && py <= y.bottom) {
      ctx.beginPath(); ctx.moveTo(x.left,py); ctx.lineTo(x.right,py); ctx.stroke();
      ctx.setLineDash([]); ctx.fillStyle='#94a3b8'; ctx.font='11px Arial';
      ctx.fillText('p='+curPval, x.left+4, py-4); ctx.setLineDash([5,4]);
    }
    [-curLfc, curLfc].forEach(v => {
      const px = x.getPixelForValue(v);
      if (px >= x.left && px <= x.right) {
        ctx.beginPath(); ctx.moveTo(px,y.top); ctx.lineTo(px,y.bottom); ctx.stroke();
        ctx.setLineDash([]); ctx.fillStyle='#94a3b8'; ctx.font='11px Arial';
        ctx.fillText((v>0?'+':'')+v.toFixed(2), px+3, y.top+12); ctx.setLineDash([5,4]);
      }
    });
    ctx.restore();
  }
};
Chart.register(linePlugin);

const DS = [
  {label:'Not significant', data:[], pointRadius:2, pointHoverRadius:5,
   backgroundColor:'rgba(148,163,184,0.3)', pointBorderWidth:0},
  {label:'Decrease',        data:[], pointRadius:3, pointHoverRadius:6,
   backgroundColor:'#3498DB', pointBorderWidth:0},
  {label:'Increase',        data:[], pointRadius:3, pointHoverRadius:6,
   backgroundColor:'#E74C3C', pointBorderWidth:0},
];

const tip = document.getElementById('tip');
vchart = new Chart(document.getElementById('vc'), {
  type:'scatter', data:{datasets:DS},
  options:{
    responsive:true, maintainAspectRatio:false,
    animation:false, devicePixelRatio:3,
    scales:{
      x:{title:{display:true,text:'log₂ Fold Change (C1 / C2)',font:{size:12}},
         grid:{color:'rgba(203,213,225,0.4)'}},
      y:{title:{display:true,text:'-log₁₀(p-value)',font:{size:12}},
         grid:{color:'rgba(203,213,225,0.4)'}}
    },
    plugins:{
      legend:{position:'top',labels:{font:{size:11},boxWidth:10}},
      tooltip:{enabled:false},
      zoom:{zoom:{wheel:{enabled:true},pinch:{enabled:true},mode:'xy'},
            pan:{enabled:true,mode:'xy'}}
    },
    onHover(evt, elements) {
      if (!elements.length) { tip.style.display='none'; return; }
      const el = elements[0];
      const d  = DS[el.datasetIndex].data[el.index];
      document.getElementById('tg').textContent = d.gene;
      document.getElementById('tf').textContent = 'log2FC : '+d.x;
      document.getElementById('tp').textContent = 'p-value: '+d.ps;
      document.getElementById('td').textContent = 'FDR    : '+(d.fdr??'n/a');
      tip.style.display='block';
    }
  }
});

function applyThresh() {
  const ns=[], up=[], dn=[];
  _sigGenes = [];
  for (const d of ALL) {
    if (Math.abs(d.x) >= curLfc && d.p <= curPval) {
      d.x > 0 ? up.push(d) : dn.push(d);
      _sigGenes.push(d.gene);
    } else ns.push(d);
  }
  DS[0].data=ns; DS[0].label=`Not significant (${ns.length})`;
  DS[1].data=dn; DS[1].label=`Decrease (${dn.length})`;
  DS[2].data=up; DS[2].label=`Increase (${up.length})`;
  document.getElementById('n-up').textContent = up.length;
  document.getElementById('n-dn').textContent = dn.length;
  document.getElementById('n-ns').textContent = ns.length;
  const tot = up.length + dn.length;
  document.getElementById('sig-count').textContent = `significant: ${tot}개`;
  document.getElementById('hm-btn').disabled = (tot === 0);
  document.getElementById('go-btn').disabled = (tot === 0);
  _enrichrId = null; _goResults = {};
  vchart.update('none');
}

function onSl() {
  curLfc  = parseFloat(document.getElementById('lfc-sl').value);
  const negP = parseFloat(document.getElementById('pval-sl').value);
  curPval = Math.pow(10, -negP);
  document.getElementById('lfc-val').textContent  = '>= '+curLfc.toFixed(2);
  document.getElementById('pval-val').textContent = '<= '+curPval.toExponential(1);
  applyThresh();
  const view = document.querySelector('.view:not(.hidden)');
  if (view && view.id === 'heatmap-view') renderHeatmap();
}

function hideAllViews() {
  document.querySelectorAll('.view').forEach(v => v.classList.add('hidden'));
  ['volcano-btns','heatmap-btns','go-btns'].forEach(id =>
    document.getElementById(id).style.display='none');
}
function showVolcano() {
  hideAllViews();
  document.getElementById('volcano-view').classList.remove('hidden');
  document.getElementById('volcano-btns').style.display='flex';
  document.getElementById('main-title').textContent='CPTAC HCC — C1 vs C2 · Volcano Plot';
  setTimeout(()=>vchart&&vchart.resize(),50);
}
function showHeatmap() {
  hideAllViews();
  document.getElementById('heatmap-view').classList.remove('hidden');
  document.getElementById('heatmap-btns').style.display='flex';
  document.getElementById('main-title').textContent='CPTAC HCC — C1 vs C2 · Heatmap';
  renderHeatmap();
}
function showGo() {
  hideAllViews();
  document.getElementById('go-view').classList.remove('hidden');
  document.getElementById('go-btns').style.display='flex';
  document.getElementById('main-title').textContent='CPTAC HCC — C1 vs C2 · GO Enrichment';
  runGo();
}

function zscore(arr) {
  const mean=arr.reduce((a,b)=>a+b,0)/arr.length;
  const std=Math.sqrt(arr.reduce((a,b)=>a+(b-mean)**2,0)/arr.length)||1;
  return arr.map(v=>Math.max(-3,Math.min(3,(v-mean)/std)));
}
function zColor(z) {
  const t=(z+3)/6;
  if(t<=0.5){const u=t*2;return `rgb(${~~(33+u*214)},${~~(102+u*145)},${~~(172+u*75)})`;}
  else{const u=(t-0.5)*2;return `rgb(${~~(247+u*(-69))},${~~(247+u*(-223))},${~~(247+u*(-204))})`;}
}
function renderHeatmap() {
  const sig=[...ALL.filter(d=>Math.abs(d.x)>=curLfc&&d.p<=curPval)].sort((a,b)=>a.x-b.x);
  document.getElementById('hm-sig-badge').textContent=`Significant ${sig.length}개`;
  document.getElementById('hm-threshold-note').textContent=
    `|log2FC|>=${curLfc.toFixed(2)} & p<=${curPval.toExponential(1)}`;
  const cvs=document.getElementById('hm-canvas'),ctx=cvs.getContext('2d');
  if(!sig.length){
    ctx.clearRect(0,0,cvs.width,cvs.height);
    ctx.fillStyle='#94a3b8';ctx.font='14px sans-serif';ctx.textAlign='center';
    ctx.fillText('현재 기준에서 significant 단백질이 없습니다',cvs.width/2,cvs.height/2);
    return;
  }
  const avail=sig.filter(d=>QUANT[d.gene]);
  if(!avail.length)return;
  const W=cvs.width,H=cvs.height,nG=avail.length,nS=SAMP.length;
  const mL=Math.min(110,14*Math.max(...avail.map(d=>d.gene.length)));
  const mR=100,mT=48,mB=40,pW=W-mL-mR,pH=H-mT-mB;
  const cW=pW/nS,cH=pH/nG;
  ctx.clearRect(0,0,W,H);ctx.fillStyle='#fff';ctx.fillRect(0,0,W,H);
  const gc=['#3498DB','#3498DB','#3498DB','#3498DB','#3498DB',
            '#E74C3C','#E74C3C','#E74C3C','#E74C3C','#E74C3C'];
  SAMP.forEach((s,i)=>{
    ctx.fillStyle=gc[i];ctx.fillRect(mL+i*cW,mT-18,cW-1,10);
    ctx.fillStyle='#334155';ctx.font='10px JetBrains Mono,monospace';
    ctx.textAlign='center';ctx.fillText(s,mL+i*cW+cW/2,mT-4);
  });
  avail.forEach((d,gi)=>{
    zscore(QUANT[d.gene]).forEach((z,si)=>{
      ctx.fillStyle=zColor(z);
      ctx.fillRect(mL+si*cW,mT+gi*cH,cW-0.5,cH-0.5);
    });
  });
  const fs=Math.min(11,Math.max(6,cH*0.75));
  ctx.textAlign='right';ctx.fillStyle='#1e293b';
  ctx.font=`${fs}px Noto Sans KR,sans-serif`;
  avail.forEach((d,gi)=>ctx.fillText(d.gene,mL-4,mT+gi*cH+cH*0.5+fs*0.35));
  avail.forEach((d,gi)=>{
    const cy=mT+gi*cH,fc=d.x;
    ctx.fillStyle=fc>0?`rgba(231,76,60,${Math.min(1,Math.abs(fc)/3)})`:`rgba(52,152,219,${Math.min(1,Math.abs(fc)/3)})`;
    ctx.fillRect(W-mR+6,cy,14,cH-0.5);
  });
  ctx.fillStyle='#475569';ctx.font='10px Arial';ctx.textAlign='left';
  ctx.fillText('log2FC',W-mR+4,mT-6);
  const lX=W-mR+4,lY=mT+pH*0.5-60,lH=120;
  const gr=ctx.createLinearGradient(0,lY,0,lY+lH);
  gr.addColorStop(0,'#2166AC');gr.addColorStop(0.5,'#F7F7F7');gr.addColorStop(1,'#B2182B');
  ctx.fillStyle=gr;ctx.fillRect(lX+20,lY,12,lH);
  ctx.strokeStyle='#e2e8f0';ctx.lineWidth=0.5;ctx.strokeRect(lX+20,lY,12,lH);
  ctx.fillStyle='#475569';ctx.font='10px Arial';ctx.textAlign='left';
  ctx.fillText('-3',lX+35,lY+5);ctx.fillText(' 0',lX+35,lY+lH/2+4);
  ctx.fillText('+3',lX+35,lY+lH);ctx.fillText('Z',lX+22,lY-6);
}

async function runGo() {
  if(_sigGenes.length<3){
    showGoError('significant 단백질이 너무 적습니다 (최소 3개 필요).\nthreshold를 완화해보세요.');
    return;
  }
  setGoLoading(true);
  document.getElementById('go-sig-badge').textContent=`Significant ${_sigGenes.length}개`;
  document.getElementById('go-threshold-note').textContent=
    `|log2FC|>=${curLfc.toFixed(2)} & p<=${curPval.toExponential(1)}`;
  try {
    if(!_enrichrId){
      const fd=new FormData();
      fd.append('list',_sigGenes.join('\n'));
      fd.append('description','volcano_sig');
      const r1=await fetch('https://maayanlab.cloud/Enrichr/addList',{method:'POST',body:fd});
      if(!r1.ok)throw new Error(`Enrichr 연결 실패 (${r1.status})`);
      _enrichrId=(await r1.json()).userListId;
    }
    if(!_goResults[_curGeneSet]){
      const r2=await fetch(`https://maayanlab.cloud/Enrichr/enrich?userListId=${_enrichrId}&backgroundType=${_curGeneSet}`);
      if(!r2.ok)throw new Error(`GO 데이터 로드 실패 (${r2.status})`);
      const j2=await r2.json();
      _goResults[_curGeneSet]=j2[_curGeneSet]||[];
    }
    setGoLoading(false);
    drawGoBubble(_goResults[_curGeneSet]);
  } catch(e){
    showGoError('⚠️ '+e.message+'\n(인터넷 연결 확인 또는 잠시 후 재시도)');
  }
}
function setGoLoading(on){document.getElementById('go-loading').classList.toggle('hidden',!on);}
function showGoError(msg){
  setGoLoading(false);
  const cvs=document.getElementById('go-canvas'),ctx=cvs.getContext('2d');
  ctx.clearRect(0,0,cvs.width,cvs.height);
  ctx.fillStyle='#94a3b8';ctx.font='13px sans-serif';ctx.textAlign='center';
  msg.split('\n').forEach((l,i)=>ctx.fillText(l,cvs.width/2,cvs.height/2-10+i*20));
}
function drawGoBubble(terms){
  const top=terms.filter(t=>t[6]<0.1).sort((a,b)=>b[4]-a[4]).slice(0,20);
  const cvs=document.getElementById('go-canvas'),ctx=cvs.getContext('2d');
  const W=cvs.width,H=cvs.height;
  ctx.clearRect(0,0,W,H);ctx.fillStyle='#fff';ctx.fillRect(0,0,W,H);
  if(!top.length){
    ctx.fillStyle='#94a3b8';ctx.font='13px sans-serif';ctx.textAlign='center';
    ctx.fillText('FDR<0.1 기준 유의한 GO term 없음',W/2,H/2-10);
    ctx.fillText('threshold를 완화하거나 significant 단백질을 늘려보세요',W/2,H/2+12);
    return;
  }
  const mL=280,mR=130,mT=36,mB=44,pW=W-mL-mR,pH=H-mT-mB,rowH=pH/top.length;
  const maxScore=Math.max(...top.map(t=>t[4]));
  const maxCount=Math.max(...top.map(t=>t[5].length));
  const maxR=Math.min(rowH*0.45,22);
  [0.25,0.5,0.75,1.0].forEach(f=>{
    const px=mL+f*pW;
    ctx.strokeStyle='rgba(203,213,225,0.5)';ctx.lineWidth=0.5;ctx.setLineDash([3,3]);
    ctx.beginPath();ctx.moveTo(px,mT);ctx.lineTo(px,mT+pH);ctx.stroke();
    ctx.setLineDash([]);
  });
  top.forEach((term,i)=>{
    const[,name,pv,,score,genes,adjP]=term;
    const cx=mL+(score/maxScore)*pW;
    const cy=mT+i*rowH+rowH/2;
    const r=Math.max(4,Math.sqrt(genes.length/maxCount)*maxR);
    const negLogP=Math.min(10,-Math.log10(adjP));
    const t=negLogP/5;
    const col=`rgb(${~~(5+t*226)},${~~(150+t*(76-150))},${~~(5+t*55)})`;
    ctx.beginPath();ctx.arc(cx,cy,r,0,Math.PI*2);
    ctx.fillStyle=col+'bb';ctx.fill();
    ctx.strokeStyle=col;ctx.lineWidth=1;ctx.stroke();
    if(r>=10){ctx.fillStyle='white';ctx.font=`bold ${Math.min(10,r*0.65)}px Arial`;
      ctx.textAlign='center';ctx.fillText(genes.length,cx,cy+3);}
    const label=name.replace(/\(.+\)/,'').trim();
    const short=label.length>42?label.slice(0,40)+'…':label;
    ctx.fillStyle='#1e293b';ctx.font='10px Noto Sans KR,sans-serif';
    ctx.textAlign='right';ctx.fillText(short,mL-8,cy+4);
    term._cy=cy;term._cx=cx;term._r=r;
  });
  ctx.fillStyle='#475569';ctx.font='11px Arial';ctx.textAlign='center';
  ctx.fillText('Combined Score',mL+pW/2,H-8);
  [0,0.25,0.5,0.75,1.0].forEach(f=>{
    const px=mL+f*pW;
    ctx.fillStyle='#94a3b8';ctx.font='9px Arial';ctx.textAlign='center';
    ctx.fillText(Math.round(maxScore*f),px,mT+pH+14);
  });
  const lX=W-mR+10;
  ctx.fillStyle='#475569';ctx.font='bold 10px Arial';ctx.textAlign='left';
  ctx.fillText('Gene count',lX,mT+10);
  [1,Math.ceil(maxCount/2),maxCount].forEach((n,i)=>{
    const r2=Math.max(4,Math.sqrt(n/maxCount)*maxR),ly=mT+30+i*36;
    ctx.beginPath();ctx.arc(lX+16,ly,r2,0,Math.PI*2);
    ctx.fillStyle='rgba(100,116,139,0.25)';ctx.fill();
    ctx.strokeStyle='#94a3b8';ctx.lineWidth=1;ctx.stroke();
    ctx.fillStyle='#475569';ctx.font='10px Arial';ctx.textAlign='left';
    ctx.fillText(n,lX+30,ly+4);
  });
  const lgY=mT+pH-130;
  ctx.fillStyle='#475569';ctx.font='bold 10px Arial';ctx.textAlign='left';
  ctx.fillText('-log10(FDR)',lX,lgY);
  const grad=ctx.createLinearGradient(0,lgY+8,0,lgY+108);
  grad.addColorStop(0,'rgb(231,76,60)');grad.addColorStop(1,'rgb(5,150,5)');
  ctx.fillStyle=grad;ctx.fillRect(lX+4,lgY+8,12,100);
  ctx.strokeStyle='#e2e8f0';ctx.lineWidth=0.5;ctx.strokeRect(lX+4,lgY+8,12,100);
  ctx.fillStyle='#475569';ctx.font='9px Arial';
  ctx.fillText('5+',lX+20,lgY+12);ctx.fillText('2.5',lX+20,lgY+58);ctx.fillText('0',lX+20,lgY+110);
  cvs._terms=top;
}
function switchGeneSet(gs){
  _curGeneSet=gs;
  document.querySelectorAll('.gs-tab').forEach(b=>b.classList.toggle('active',b.dataset.gs===gs));
  if(_goResults[gs])drawGoBubble(_goResults[gs]);
  else{setGoLoading(true);runGo();}
}
document.addEventListener('DOMContentLoaded',()=>{
  document.getElementById('go-canvas').addEventListener('click',e=>{
    const cvs=document.getElementById('go-canvas');
    const rect=cvs.getBoundingClientRect();
    const mx=(e.clientX-rect.left)*(cvs.width/rect.width);
    const my=(e.clientY-rect.top)*(cvs.height/rect.height);
    if(!cvs._terms)return;
    for(const t of cvs._terms){
      const dx=mx-t._cx,dy=my-t._cy;
      if(Math.sqrt(dx*dx+dy*dy)<=t._r+4){
        const popup=document.getElementById('go-popup');
        popup.querySelector('h4').textContent=t[1];
        popup.querySelector('.genes').textContent=t[5].join(', ');
        popup.style.display='block';
        popup.style.left=(e.clientX+10)+'px';
        popup.style.top=(e.clientY-10)+'px';
        break;
      }
    }
  });
});
function saveVolcano(){
  const c=vchart.canvas,t=document.createElement('canvas');
  t.width=c.width;t.height=c.height;
  const ctx=t.getContext('2d');
  ctx.fillStyle='white';ctx.fillRect(0,0,t.width,t.height);ctx.drawImage(c,0,0);
  const a=document.createElement('a');
  a.download='cptac_hcc_volcano.png';a.href=t.toDataURL('image/png',1.0);a.click();
}
function saveHeatmap(){
  const a=document.createElement('a');
  a.download='cptac_hcc_heatmap.png';
  a.href=document.getElementById('hm-canvas').toDataURL('image/png',1.0);a.click();
}
function saveGo(){
  const a=document.createElement('a');
  a.download='cptac_hcc_go.png';
  a.href=document.getElementById('go-canvas').toDataURL('image/png',1.0);a.click();
}
function toggleNs(){
  const m=vchart.getDatasetMeta(0);m.hidden=!m.hidden;vchart.update('none');
}
document.addEventListener('mousemove',e=>{
  if(tip.style.display==='block'){
    tip.style.left=(e.clientX+14)+'px';tip.style.top=(e.clientY-10)+'px';
  }
});
applyThresh();
scale();
"""

HTML = f"""<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<title>CPTAC HCC · Volcano + Heatmap + GO</title>
<link href="https://fonts.googleapis.com/css2?family=Noto+Sans+KR:wght@300;400;500;700&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.3/dist/chart.umd.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/hammerjs@2.0.8/hammer.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chartjs-plugin-zoom@2.0.1/dist/chartjs-plugin-zoom.min.js"></script>
<style>{CSS}</style>
</head>
<body>
<div class="deck">
<div class="slide-wrapper" id="wrapper">

<div class="slide-header">
  <div class="header-left">
    <div class="accent-bar"></div>
    <h2 id="main-title">CPTAC HCC &#8212; C1 vs C2 &middot; Volcano Plot</h2>
  </div>
  <span class="hdr-badge">9,506 proteins &middot; limma moderated t-test</span>
</div>

<div class="ctrl-panel">
  <div class="ctrl-group">
    <span class="ctrl-label">log&#8322;FC</span>
    <input type="range" id="lfc-sl" min="0.5" max="3.0" step="0.05" value="1.0" oninput="onSl()">
    <span class="ctrl-val" id="lfc-val">&gt;= 1.00</span>
  </div>
  <div class="ctrl-group">
    <span class="ctrl-label">p-value</span>
    <input type="range" id="pval-sl" min="1.0" max="4.0" step="0.1" value="2.0" oninput="onSl()">
    <span class="ctrl-val" id="pval-val">&lt;= 1.0e-2</span>
  </div>

  <div id="volcano-btns" style="display:flex;align-items:center;gap:8px;margin-left:auto;">
    <span class="sig-count" id="sig-count"></span>
    <button class="btn" onclick="toggleNs()">&#9679; ns</button>
    <button class="btn" onclick="vchart&&vchart.resetZoom()">&#8635;</button>
    <button class="btn save" onclick="saveVolcano()">&#128190; PNG</button>
    <button class="btn heatmap-btn" id="hm-btn" onclick="showHeatmap()">&#128202; Heatmap</button>
    <button class="btn go-btn"      id="go-btn" onclick="showGo()">&#128300; GO &#BD84;&#C11D;</button>
  </div>
  <div id="heatmap-btns" style="display:none;align-items:center;gap:8px;margin-left:auto;">
    <button class="btn back-btn" onclick="showVolcano()">&#8592; Volcano</button>
    <button class="btn save" onclick="saveHeatmap()">&#128190; PNG</button>
  </div>
  <div id="go-btns" style="display:none;align-items:center;gap:8px;margin-left:auto;">
    <button class="btn back-btn" onclick="showVolcano()">&#8592; Volcano</button>
    <button class="btn tab gs-tab active" data-gs="GO_Biological_Process_2023"
            onclick="switchGeneSet('GO_Biological_Process_2023')">GO : BP</button>
    <button class="btn tab gs-tab" data-gs="KEGG_2021_Human"
            onclick="switchGeneSet('KEGG_2021_Human')">KEGG</button>
    <button class="btn save" onclick="saveGo()">&#128190; PNG</button>
  </div>
</div>

<div class="view" id="volcano-view">
  <div id="volcano-chart-area"><canvas id="vc"></canvas></div>
  <div class="volcano-footer">
    <div class="stats">
      <div class="stat up"><div class="n" id="n-up">&#8212;</div><div class="l">Increase &#8593;</div></div>
      <div class="stat dn"><div class="n" id="n-dn">&#8212;</div><div class="l">Decrease &#8595;</div></div>
      <div class="stat">  <div class="n" id="n-ns" style="color:#64748b;">&#8212;</div><div class="l">Not significant</div></div>
    </div>
  </div>
</div>

<div class="view hidden" id="heatmap-view">
  <div class="hm-info">
    <span class="hm-badge" id="hm-sig-badge">Significant 0&#AC1C;</span>
    <span class="hm-note"  id="hm-threshold-note"></span>
    <span style="font-size:11px;color:#94a3b8;margin-left:auto;">Z-score &middot; log2FC &#AE30;&#C900; &#C815;&#B82C;</span>
  </div>
  <div class="hm-body"><canvas id="hm-canvas"></canvas></div>
</div>

<div class="view hidden" id="go-view">
  <div class="go-info">
    <span class="go-badge" id="go-sig-badge">Significant 0&#AC1C;</span>
    <span class="hm-note"  id="go-threshold-note"></span>
    <span style="font-size:11px;color:#94a3b8;margin-left:auto;">Enrichr API &middot; FDR&lt;0.1 &middot; Combined Score &#C815;&#B82C;</span>
  </div>
  <div class="go-body">
    <canvas id="go-canvas"></canvas>
    <div id="go-loading">
      <div class="spinner"></div>
      <p>Enrichr API&#B85C; GO &#BD84;&#C11D; &#C911;...</p>
    </div>
  </div>
</div>

<div class="progress-bar"></div>
</div></div>

<div id="go-popup">
  <span class="close-btn" onclick="document.getElementById('go-popup').style.display='none'">&#x2715;</span>
  <h4></h4><div class="genes"></div>
</div>
<div class="vc-tip" id="tip">
  <div class="vc-tip-gene" id="tg"></div>
  <div id="tf"></div><div id="tp"></div><div id="td"></div>
</div>

<script type="application/json" id="app-data">{DATA_JS}</script>

<script>
(function() {{
  function setSize(id, fallW, fallH) {{
    const c=document.getElementById(id), p=c.parentElement;
    function upd(){{c.width=p.clientWidth||fallW;c.height=p.clientHeight||fallH;}}
    upd(); new ResizeObserver(upd).observe(p);
  }}
  setSize('hm-canvas',1100,520);
  setSize('go-canvas',1100,520);
}})();
</script>

<script>{JS}</script>
</body>
</html>"""

# ── 5. 저장 ───────────────────────────────────────────────────
output = "volcano_interactive.html"
with open(output, "w", encoding="utf-8") as f:
    f.write(HTML)

print(f"\n완료: {output} ({len(HTML)//1024}KB)")
print("브라우저에서 열면 바로 사용 가능합니다.")
