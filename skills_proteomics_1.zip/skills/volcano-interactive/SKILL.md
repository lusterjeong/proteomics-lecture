---
name: volcano-interactive
description: >
  DE 결과 + quant 데이터로 Volcano + Heatmap + GO 분석을 하나의 HTML에 통합 생성합니다.
  슬라이더로 threshold 실시간 조정, Heatmap/GO 뷰 전환, Enrichr API GO 분석 포함.
  "인터랙티브 volcano", "volcano heatmap GO", "volcano html 만들어줘" 요청 시 실행.
---

# 인터랙티브 Volcano + Heatmap + GO 통합 HTML 생성

## 원칙

이 스킬은 **원본 코드 파일을 그대로 사용**합니다.
CSS / JS / HTML 구조를 임의로 변경하지 않으며, **데이터 로드 부분만 수정**합니다.

---

## 원본 코드 (항상 이 코드를 기반으로 실행)

!`cat ~/.claude/skills/volcano-interactive/generate_volcano.py`

---

## 실행 방법

### 1. 위 원본 코드에서 데이터 로드 부분만 수정

```python
# ── 1. 데이터 로드 ── 이 부분만 수정
de    = pd.read_csv('내_DE파일.csv',    index_col=0)
quant = pd.read_csv('내_quant파일.csv', index_col=0)
```

컬럼명이 다르면 rename 추가:
```python
de = de.rename(columns={'log2FoldChange':'log2FC', 'pvalue':'p_value', 'padj':'FDR'})
```

### 2. CSS / JS / HTML 구조 변경 금지

- `CSS = """..."""` 블록 수정 금지
- `JS = r"""..."""` 블록 수정 금지
- HTML 구조 변경 금지
- 라이브러리 변경 금지 (Chart.js → Plotly 등 절대 금지)

### 3. 수정한 코드 실행 후 HTML 파일 전달

---

## 자주 발생하는 오류

| 오류 | 원인 | 해결 |
|------|------|------|
| 화면이 비어 있음 | JS f-string `{ }` 이스케이프 누락 | JS는 반드시 `r"""..."""` 사용 |
| Plotly/Chart 충돌 | 두 라이브러리 동시 로드 | Chart.js만 사용 |
| Canvas 높이 0 | ResizeObserver 미적용 | `p.clientHeight \|\| 540` 폴백 |
| GO 결과 없음 | significant 단백질 < 3개 | threshold 완화 |
